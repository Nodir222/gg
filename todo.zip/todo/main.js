let body = document.querySelector('body')






function DarktMode() {
    body.style.backgroundColor ='white'
}